import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const TextStyle appBarTextStyle = TextStyle(
      color: Colors.white,
      fontSize: 20,
      fontWeight: FontWeight.bold,
    );

    const TextStyle buttonTextStyle = TextStyle(
      fontSize: 18,
    );

    return MaterialApp(
      home: Builder(
        builder: (context) => Scaffold(
          appBar: AppBar(
            centerTitle: true,
            backgroundColor: const Color.fromRGBO(40, 159, 36, 1),
            title: const Text('GroveG', style: appBarTextStyle),
          ),
          body: LayoutBuilder(
            builder: (context, constraints) {
              return Stack(
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Image.asset('assets/Dünya1.png'),
                    ),
                  ),
                  Positioned(
                    top: constraints.maxHeight * 0.6,
                    left: constraints.maxWidth * 0.1,
                    child: const Text(
                      '''Dünya bizim için var değil,
                      bizimle var.
                            ''',
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 50),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: constraints.maxWidth * 0.5,
                            height: 50,
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const SignUpPage(),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                textStyle: buttonTextStyle,
                              ),
                              child: const Text('Başla'),
                            ),
                          ),
                          const SizedBox(height: 16),
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const SignInPage(),
                                ),
                              );
                            },
                            child: const Text(
                              'Zaten hesabınız var mı? Giriş Yapın',
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _passwordVisible = false;

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _signUp() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kayıt işlemi gerçekleştiriliyor...')),
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => const HomePage()), // Ana sayfaya yönlendirme
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kayıt Ol'),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: screenHeight * 0.05),
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextFormField(
                        controller: _fullNameController,
                        decoration: const InputDecoration(
                          labelText: 'Tam Ad',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Lütfen tam adınızı girin';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _emailController,
                        decoration: const InputDecoration(
                          labelText: 'E-posta',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Lütfen e-posta adresinizi girin';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _passwordController,
                        obscureText: !_passwordVisible,
                        decoration: InputDecoration(
                          labelText: 'Şifre',
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _passwordVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            onPressed: () {
                              setState(() {
                                _passwordVisible = !_passwordVisible;
                              });
                            },
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Lütfen şifrenizi girin';
                          } else if (value.length < 8) {
                            return 'Şifre en az 8 karakter olmalıdır';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _confirmPasswordController,
                        obscureText: !_passwordVisible,
                        decoration: const InputDecoration(
                          labelText: 'Şifreyi Onayla',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Lütfen şifrenizi onaylayın';
                          } else if (value != _passwordController.text) {
                            return 'Şifreler uyuşmuyor';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 32),
                      SizedBox(
                        width: screenWidth * 0.5,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: _signUp,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                            textStyle: const TextStyle(
                              fontSize: 18,
                            ),
                          ),
                          child: const Text('Kayıt Ol'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SignInPage extends StatelessWidget {
  const SignInPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Giriş Yap'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Hesabınıza Giriş Yapın',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'E-posta',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Şifre',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () {
                  // Giriş işlemleri burada yapılacak
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  textStyle: const TextStyle(
                    fontSize: 18,
                  ),
                ),
                child: const Text('Giriş Yap'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ana Sayfa'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Hoş Geldiniz!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () async {
                const url = 'https://sifiratik.gov.tr/kutuphane/haberler';
                if (await canLaunch(url)) {
                  await launch(url);
                } else {
                  throw 'Haberler sayfası açılamadı: $url';
                }
              },
              child: const Text('Haberler'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const RecyclingIdeasPage()),
                );
              },
              child: const Text('Geri Dönüşüm Fikirleri'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RecycleGameApp()),
                );
              },
              child: const Text('Mini Oyun'),
            ),
          ],
        ),
      ),
    );
  }
}

class RecycleGameApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Geri Dönüşüm Oyunu',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: RecycleGamePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class RecycleGamePage extends StatefulWidget {
  @override
  _RecycleGamePageState createState() => _RecycleGamePageState();
}

class _RecycleGamePageState extends State<RecycleGamePage>
    with SingleTickerProviderStateMixin {
  final int totalItems = 20;
  List<RecyclableItem> items = [];
  List<RecyclableItem> collectedItems = [];
  late Timer timer;
  double trashPosition = 0.0;
  double screenWidth = 0.0;
  double screenHeight = 0.0;
  bool isGameOver = false;
  bool isGameWon = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        screenWidth = MediaQuery.of(context).size.width;
        screenHeight = MediaQuery.of(context).size.height;
        for (int i = 0; i < totalItems; i++) {
          RecyclableItemType itemType = RecyclableItemType
              .values[Random().nextInt(RecyclableItemType.values.length)];
          items.add(RecyclableItem(
            id: i,
            type: itemType,
            position: Offset(
              Random().nextDouble() * (screenWidth - 50),
              -Random().nextDouble() * 300,
            ),
            size: 50.0,
            speed: _calculateSpeed(itemType),
            assetPath: _getAssetPath(itemType),
          ));
        }
      });
      startFalling();
    });
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  double _calculateSpeed(RecyclableItemType type) {
    switch (type) {
      case RecyclableItemType.Paper:
        return 1.5;
      case RecyclableItemType.CigaretteButt:
        return 1.0;
      case RecyclableItemType.MetalCan:
        return 0.8;
      case RecyclableItemType.PlasticBag:
        return 1.2;
      case RecyclableItemType.GlassBottle:
        return 0.5;
      default:
        return 1.0;
    }
  }

  String _getAssetPath(RecyclableItemType type) {
    switch (type) {
      case RecyclableItemType.Paper:
        return 'assets/paper.png';
      case RecyclableItemType.CigaretteButt:
        return 'assets/cigarette_butt.png';
      case RecyclableItemType.MetalCan:
        return 'assets/metal_can.png';
      case RecyclableItemType.PlasticBag:
        return 'assets/plastic_bag.png';
      case RecyclableItemType.GlassBottle:
        return 'assets/glass_bottle.png';
      default:
        return '';
    }
  }

  void startFalling() {
    timer = Timer.periodic(Duration(milliseconds: 30), (timer) {
      setState(() {
        for (var item in items) {
          item.position =
              Offset(item.position.dx, item.position.dy + item.speed);
          if (item.position.dy > screenHeight - 100) {
            isGameOver = true;
            timer.cancel();
            showEndDialog(false, item); // Kaybedilen nesne bilgisini ekliyoruz
          }
        }

        if (collectedItems.length == totalItems) {
          isGameWon = true;
          timer.cancel();
          showEndDialog(true, null); // Kazanma durumunda item bilgisi yok
        }
      });
    });
  }

  void showEndDialog(bool isWin, RecyclableItem? lostItem) {
    String itemInfo = '';
    if (lostItem != null) {
      switch (lostItem.type) {
        case RecyclableItemType.Paper:
          itemInfo =
              'Kağıt doğada yaklaşık 2-5 ayda çözünür ve geri dönüştürülebilir.';
          break;
        case RecyclableItemType.CigaretteButt:
          itemInfo =
              'Sigara izmariti doğada 1-5 yıl kalır ve çevreye zarar verir.';
          break;
        case RecyclableItemType.MetalCan:
          itemInfo =
              'Metal kutular doğada 50-200 yıl kalabilir, ancak geri dönüştürülebilir.';
          break;
        case RecyclableItemType.PlasticBag:
          itemInfo =
              'Plastik poşetler doğada 10-20 yıl kalır ve çevreye büyük zarar verir.';
          break;
        case RecyclableItemType.GlassBottle:
          itemInfo =
              'Cam şişeler 1 milyon yıl veya daha fazla sürede çözünür, ancak %100 geri dönüştürülebilir.';
          break;
        default:
          itemInfo = 'Bilinmeyen nesne.';
      }
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(isWin ? 'Tebrikler!' : 'Oyun Bitti'),
        content: Text(
          isWin
              ? 'Tüm geri dönüşüm nesnelerini topladınız!'
              : 'Bir nesne yere ulaştı. Oyunu kaybettiniz! \n\nKaybettiren nesne: $itemInfo',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              restartGame();
            },
            child: Text('Yeniden Başla'),
          ),
        ],
      ),
    );
  }

  void restartGame() {
    setState(() {
      items.clear();
      collectedItems.clear();
      isGameOver = false;
      isGameWon = false;
      trashPosition = (screenWidth - 100) / 2;
      for (int i = 0; i < totalItems; i++) {
        RecyclableItemType itemType = RecyclableItemType
            .values[Random().nextInt(RecyclableItemType.values.length)];
        items.add(RecyclableItem(
          id: i,
          type: itemType,
          position: Offset(
            Random().nextDouble() * (screenWidth - 50),
            -Random().nextDouble() * 300,
          ),
          size: 50.0,
          speed: _calculateSpeed(itemType),
          assetPath: _getAssetPath(itemType),
        ));
      }
      startFalling();
    });
  }

  void moveTrash(double delta) {
    setState(() {
      trashPosition += delta;
      if (trashPosition < 0) {
        trashPosition = 0;
      } else if (trashPosition > screenWidth - 100) {
        trashPosition = screenWidth - 100;
      }
      List<RecyclableItem> toCollect = [];
      for (var item in items) {
        if (item.position.dy + item.size >= screenHeight - 100) {
          if (item.position.dx + item.size > trashPosition &&
              item.position.dx < trashPosition + 100) {
            toCollect.add(item);
            collectedItems.add(item);
          }
        }
      }
      items.removeWhere((item) => toCollect.contains(item));
    });
  }

  @override
  Widget build(BuildContext context) {
    if (screenWidth == 0.0 || screenHeight == 0.0) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Geri Dönüşüm Oyunu'),
      ),
      body: GestureDetector(
        onHorizontalDragUpdate: (details) {
          moveTrash(details.delta.dx);
        },
        child: Stack(
          children: [
            ...items.map((item) {
              return Positioned(
                left: item.position.dx,
                top: item.position.dy,
                child: Image.asset(
                  item.assetPath,
                  width: item.size,
                  height: item.size,
                ),
              );
            }).toList(),
            Positioned(
              left: trashPosition,
              bottom: 20,
              child: Container(
                width: 100,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.brown,
                  borderRadius: BorderRadius.circular(12),
                  image: DecorationImage(
                    image: AssetImage('dönkutu.png'),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Icon(
                  Icons.delete,
                  color: Colors.white,
                  size: 40,
                ),
              ),
            ),
            Positioned(
              top: 20,
              left: 20,
              child: Text(
                'Toplanan: ${collectedItems.length}/$totalItems',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

enum RecyclableItemType {
  Paper,
  CigaretteButt,
  MetalCan,
  PlasticBag,
  GlassBottle
}

class RecyclableItem {
  final int id;
  final RecyclableItemType type;
  Offset position;
  final double size;
  final double speed;
  final String assetPath;

  RecyclableItem({
    required this.id,
    required this.type,
    required this.position,
    required this.size,
    required this.speed,
    required this.assetPath,
  });
}

class RecyclingIdeasPage extends StatelessWidget {
  const RecyclingIdeasPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Geri Dönüşüm Fikirleri'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: const [
            ListTile(
              title: Text('1. Kağıt Geri Dönüşümü'),
              subtitle: Text('Eski kağıtları geri dönüştürün.'),
            ),
            ListTile(
              title: Text('2. Plastik Şişe Kullanımı'),
              subtitle: Text('Plastik şişeleri saksı olarak kullanın.'),
            ),
            ListTile(
              title: Text('3. Cam Şişe Değerlendirme'),
              subtitle: Text('Cam şişeleri dekoratif objelere dönüştürün.'),
            ),
            ListTile(
              title: Text('4. Eski Kıyafetlerin Yeniden Kullanımı'),
              subtitle: Text('Eski kıyafetlerinizi kesip yeni ürünler yapın.'),
            ),
            ListTile(
              title: Text('5. Elektronik Atıkların Geri Dönüşümü'),
              subtitle: Text('Eski elektronik cihazlarınızı geri dönüştürün.'),
            ),
            ListTile(
              title: Text('6. Ahşap Eşyaların Değerlendirilmesi'),
              subtitle: Text('Eski ahşap mobilyaları yeniden kullanın.'),
            ),
          ],
        ),
      ),
    );
  }
}
